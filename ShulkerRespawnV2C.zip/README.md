# Shulker Respawn V2 Data Pack for Minecraft 1.15 / 1.16.X ++
This data pack allows Shulkers to spawn in End Cities

Uses Enderman spawning to replace one of them in a set of conditions of distance to the player, distance between other shulkers, biomes and blocks.

To install it just drop the data pack zip file in your world's "datapacks" folder. Please note that there more than one data pack option is available in this repository, you only need one file.

You can find more information about this data pack here

Or watch the following video https://www.youtube.com/watch?v=fUc7r9bkXQE


## Changelog:
- Swaped advancements for predicates to detect biomes
- Fixed a condition that would make the condition to check for other shulkers around not work due to a bug in Minecraft
- Added an alternative data pack with random colored Shulker boxes to add some color to your world :)

## Credits
Thanks to MaizumaGames for the swapping mechanic and random coloring ideas.

