## Illusioner Raids V1.0.3 ##
This data pack will add Illusioners into the world and give them a reason to be in the game!

## Usage ##
When the player has Bad Omen effect level 2 or more and activate a raid a Illusioner will appear in the final wave and join the raid

## Spawn Mechanics ##
Illsioners will spawn in different amounts based on the games difficulty:
> Easy Mode: Minimum of 1
> Normal Mode: Minimum of 2
> Hard Mode: Minimum of 4

## Drops ##
Vanilla Minecraft only gives the illusioner a bow drop at death, so since they're magic and can turn invisible this pack added a couple of extras
- Bow
- Potion of Invisibility
- Enchanted Book (random)
- Illusioners Mystery Potion (a potion that will give you 2 effects, but which 2?)

Each drop has a different drop chance that scales with the looting enchantment

## Advancements ##
There is 1 visible advancements and 2 hidden advancements in this data pack,
The main hidden Advancement for this pack is called "Potion Farming?", this will be unlocked when you have killed enough illusioners, at which
point you will receive a trophy!

## Bug Fix ##
If you have any issues with the pack not triggering an event you can run the following command which may fix it:
/function 8bm:reset

If you want to uninstall the pack, including all the scoreboards use the following commands
/function uninstall.illusioner_raids

## Declared Tags, FakePlayers, Scoreboards, Storage ##
If you are experiencing any compatibility issues my pack please make sure that the other pack isn't using any of the following:

- Main Directory
# 8bm

- Tags
# 8bm.illraid
# 8bm.ir.illusioner

- FakePlayers
# 8bm.bool
# 8bm.diff.mode

- Scoreboard Objectives
# 8bm.difficulty
# 8bm.ir.kills
# 8bm.feedback
# 8bm.uninstall

## Socials ##

For more packs and for updates on packs that I have created you can find me at these places
- http://YouTube.com/The8BitMonkey
- http://www.The8BitMonkey.com/discord
- http://www.Twitter.com/The8BitMonkey
- http://www.planetminecraft.com/member/the8bitmonkey/

## Big Thanks ##
Thank you to the following community members for there tutorials and packs which helped me understand how datapacks work and how to create my own!
- CloudWolf: https://www.youtube.com/channel/UCZnBqVITQ0dloqUU0fGxY3g
- Lagitimoose: https://www.youtube.com/channel/UCFkT7atm3HrSm5nYaXah5Ww
- GameMode4: https://gm4.co/
- Boomber: https://www.planetminecraft.com/member/boomber360/
- TimberForge: https://www.youtube.com/channel/UC606Jh3yjNj40dcVuMwtUCw
- Blakens: https://www.youtube.com/channel/UCP2FPkHsjojo2OJmXqSUk9Q
- Swashbuckle Games: https://www.youtube.com/channel/UCTvbLAf66VfMPlh8dIKnSEQ
- LittleWorldOfLilcat: https://www.youtube.com/channel/UClpZU5eeU9r0zfgu-34VNYg (for being such a supportive partner and testing all my packs)

## Change Log ##
Version 1.0.3
Separated difficulty checks into different functions so not all running for 1 checks
Tied the Advancement "Where'd they go" into the raids
Rewrote uninstall script
Changed command structure
Added efficiency to the way functions are activated
Changed ## Comments

Version 1.0.2
Added predicate for cross-pack integration check
Added load function
Changed minecraft:load target

Version 1.0.1
Added head name to trophies so that if they're placed and broken they retain some of the name
Fixed several bugs related to installation text
Added changelog
